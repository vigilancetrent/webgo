louis chifura is my name fastly i would like thanks God for the great thing he has given to me 


when starting this application u will asked to set your master key ,i have done this for security reasons do so thank u for more info contact me on 
www.facebook.com/chifural
www.twitter.com/@royalchif
louischifura@gmail.com

